Hierarchiccal agglomerative takes a little time to plot.
It takes about 5 minutes to get values for 1 linkage algrithm

So it may take upto 15 minutes or more for all 3 plots

But in Google colab, it takes around 5-7 minutes to plot all
